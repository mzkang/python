## <file handling>



#lab 7-1 ------틀림(format)------

enter = input('파일 이름을 입력하세요...: ')


file = open(enter, mode = 'r', encoding = 'utf-8').readlines()

for i in range(len(file)):
    print('{:4}:{}'.format(i+1, file[i]), end = '')




#lab 7-2-A
 # 내용을 'head.py'로 저장


#lab 7-2-B
 # 내용을 'tail.py'로 저장


#lab 7-2-C
 # 내용을 'body.py'로 저장


#lab 7-3-A
 # 내용을 count_uniquewords.py'로 저장
 


