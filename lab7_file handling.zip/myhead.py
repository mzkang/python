import sys


file = open(sys.argv[2], mode = 'r', encoding = 'utf-8').readlines()


if count > len(lines):
    count = len(lines)
for i in range(sys.arvg[1]):
    print(file[i])
    
